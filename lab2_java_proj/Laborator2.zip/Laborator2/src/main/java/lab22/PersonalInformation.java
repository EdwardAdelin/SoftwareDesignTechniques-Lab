package lab22;

public interface PersonalInformation {
    String getPersonalInformation();
}
