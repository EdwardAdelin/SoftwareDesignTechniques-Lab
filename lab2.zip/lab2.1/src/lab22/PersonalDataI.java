package lab22;

import java.time.LocalDate;

public interface PersonalDataI {
    String getName();
    LocalDate getBDay();
    String getEmail();
    String getTelephone();
}
