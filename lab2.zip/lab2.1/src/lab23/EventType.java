package lab23;

public enum EventType {
    FIRE,
    INTRUSION,
    WATER,
    TEMPERATURE
}