package lab21;

public interface MyComparator<T> {
    int compare(T t1, T t2);
}
